-- phpMyAdmin SQL Dump
-- version 5.2.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Mar 14, 2026 at 04:01 PM
-- Server version: 8.4.7
-- PHP Version: 8.3.28

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `gettakafulb`
--

-- --------------------------------------------------------

--
-- Table structure for table `cache`
--

DROP TABLE IF EXISTS `cache`;
CREATE TABLE IF NOT EXISTS `cache` (
  `key` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `value` mediumtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `expiration` int NOT NULL,
  PRIMARY KEY (`key`),
  KEY `cache_expiration_index` (`expiration`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `cache_locks`
--

DROP TABLE IF EXISTS `cache_locks`;
CREATE TABLE IF NOT EXISTS `cache_locks` (
  `key` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `owner` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `expiration` int NOT NULL,
  PRIMARY KEY (`key`),
  KEY `cache_locks_expiration_index` (`expiration`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `claims`
--

DROP TABLE IF EXISTS `claims`;
CREATE TABLE IF NOT EXISTS `claims` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `group_id` bigint UNSIGNED NOT NULL,
  `claimant_id` bigint UNSIGNED NOT NULL,
  `title` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `claimant_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `policy_number` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'pending',
  `date_of_incident` date DEFAULT NULL,
  `time_of_incident` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `amount_claimed` decimal(10,2) NOT NULL DEFAULT '0.00',
  `location_of_incident` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `type_of_incident` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `estimated_cost_of_repairs` decimal(10,2) NOT NULL DEFAULT '0.00',
  `description_of_incident` text COLLATE utf8mb4_unicode_ci,
  `damage_description` text COLLATE utf8mb4_unicode_ci,
  `vehicle_details` text COLLATE utf8mb4_unicode_ci,
  `witness_details` text COLLATE utf8mb4_unicode_ci,
  `bank_account_details` text COLLATE utf8mb4_unicode_ci,
  `declaration` text COLLATE utf8mb4_unicode_ci,
  `photos_of_the_damage` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `police_report_file` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `digital_signature` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `voting_deadline` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `claims_group_id_foreign` (`group_id`),
  KEY `claims_claimant_id_foreign` (`claimant_id`)
) ENGINE=MyISAM AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `claims`
--

INSERT INTO `claims` (`id`, `group_id`, `claimant_id`, `title`, `claimant_name`, `policy_number`, `status`, `date_of_incident`, `time_of_incident`, `amount_claimed`, `location_of_incident`, `type_of_incident`, `estimated_cost_of_repairs`, `description_of_incident`, `damage_description`, `vehicle_details`, `witness_details`, `bank_account_details`, `declaration`, `photos_of_the_damage`, `police_report_file`, `digital_signature`, `voting_deadline`, `created_at`, `updated_at`) VALUES
(1, 1, 3, 'Car Accident - Front Bumper', 'User Test1', 'POL-06EB61B8', 'pending', '2026-03-11', '14:00', 2500.00, 'Toronto, ON', 'Vehicle Collision', 0.00, 'Rear-ended at traffic light, front bumper and hood damaged.', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2026-03-20 23:10:43', '2026-03-13 23:10:43', '2026-03-13 23:10:43'),
(2, 2, 4, 'Water Damage - Basement Flood', 'User Test2', 'POL-E0C64119', 'pending', '2026-03-11', '12:00', 4200.00, 'Toronto, ON', 'Water Damage', 0.00, 'Basement flooded due to pipe burst during winter.', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2026-03-20 23:10:43', '2026-03-13 23:10:43', '2026-03-13 23:10:43'),
(3, 3, 5, 'Theft - Laptop Stolen', 'User Test3', 'POL-298F95E1', 'pending', '2026-03-12', '11:00', 1800.00, 'Toronto, ON', 'Theft', 0.00, 'Laptop stolen from car while parked at mall.', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2026-03-20 23:10:43', '2026-03-13 23:10:43', '2026-03-13 23:10:43'),
(4, 4, 6, 'Fire Damage - Kitchen', 'User Test4', 'POL-9B698EB3', 'pending', '2026-03-05', '11:00', 6500.00, 'Toronto, ON', 'Fire', 0.00, 'Kitchen fire caused damage to cabinets and appliances.', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2026-03-20 23:10:43', '2026-03-13 23:10:43', '2026-03-13 23:10:43'),
(5, 5, 7, 'Windshield Crack', 'User Test5', 'POL-872488F8', 'pending', '2026-03-12', '10:00', 800.00, 'Toronto, ON', 'Vehicle Damage', 0.00, 'Rock hit windshield on highway causing large crack.', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2026-03-20 23:10:43', '2026-03-13 23:10:43', '2026-03-13 23:10:43'),
(6, 6, 1, 'Fender Bender - Parking Lot', 'Tanzilur Rahman', 'POL-B73CE398', 'pending', '2026-03-12', '19:00', 1200.00, 'Calgary, AB', 'Vehicle Collision', 0.00, 'Minor collision in parking lot.', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2026-03-20 23:10:43', '2026-03-13 23:10:43', '2026-03-13 23:10:43'),
(7, 7, 1, 'Broken Window - Storm', 'Tanzilur Rahman', 'POL-A4A042CF', 'approved', '2026-03-09', '10:00', 950.00, 'Calgary, AB', 'Storm Damage', 0.00, 'Window shattered during hailstorm.', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2026-03-20 23:10:43', '2026-03-13 23:10:43', '2026-03-13 23:10:43'),
(8, 8, 1, 'Medical Emergency', 'Tanzilur Rahman', 'POL-4C5BDE74', 'pending', '2026-03-11', '20:00', 3500.00, 'Calgary, AB', 'Health', 0.00, 'Emergency room visit after accident.', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2026-03-20 23:10:43', '2026-03-13 23:10:43', '2026-03-13 23:10:43'),
(14, 12, 11, 'Minor Repair Claim', 'GetTakaful Inc.', 'POL-TESLA003', 'complete', '2025-09-05', '16:00', 500.00, 'Vancouver, BC', 'Minor Damage', 0.00, 'Side mirror replacement.', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2025-09-18 18:00:00', '2026-03-14 00:58:17', '2026-03-14 00:58:17'),
(13, 12, 11, 'Insurance Review Claim', 'GetTakaful Inc.', 'POL-TESLA002', 'approved', '2025-09-28', '10:00', 0.00, 'Calgary, AB', 'Policy Review', 0.00, 'Annual policy review and assessment.', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2025-10-11 18:00:00', '2026-03-14 00:58:17', '2026-03-14 00:58:17'),
(12, 12, 8, 'Vehicle Damage Claim', 'Test Takaful', 'POL-TESLA001', 'complete', '2025-10-01', '14:00', 2000.00, 'Toronto, ON', 'Vehicle Collision', 0.00, 'Front bumper damage from collision.', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2025-10-13 18:00:00', '2026-03-14 00:58:17', '2026-03-14 00:58:17'),
(15, 16, 4, 'Home Water Damage', 'User Test2', 'POL-FAM001', 'pending', '2026-03-01', '09:00', 750.00, 'Ottawa, ON', 'Water Damage', 0.00, 'Basement flooded due to pipe burst.', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2026-03-21 01:27:27', '2026-03-14 01:27:27', '2026-03-14 01:27:27');

-- --------------------------------------------------------

--
-- Table structure for table `failed_jobs`
--

DROP TABLE IF EXISTS `failed_jobs`;
CREATE TABLE IF NOT EXISTS `failed_jobs` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `uuid` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `connection` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `groups`
--

DROP TABLE IF EXISTS `groups`;
CREATE TABLE IF NOT EXISTS `groups` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `creator_id` bigint UNSIGNED NOT NULL,
  `title` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `group_token` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `amount_to_join` decimal(10,2) NOT NULL DEFAULT '0.00',
  `minimum_number_of_people` int NOT NULL DEFAULT '0',
  `management_fee` decimal(10,2) NOT NULL DEFAULT '0.00',
  `claims_processing_fee` decimal(10,2) NOT NULL DEFAULT '0.00',
  `shariah_compliance_review_fee` decimal(10,2) NOT NULL DEFAULT '0.00',
  `gettakaful_platform_fee` decimal(10,2) NOT NULL DEFAULT '0.00',
  `total_contributions` decimal(10,2) NOT NULL DEFAULT '0.00',
  `total_claims_paid` decimal(10,2) NOT NULL DEFAULT '0.00',
  `pool_balance` decimal(10,2) NOT NULL DEFAULT '0.00',
  `number_of_active_participants` int NOT NULL DEFAULT '0',
  `number_of_claims_submitted` int NOT NULL DEFAULT '0',
  `rules` text COLLATE utf8mb4_unicode_ci,
  `status` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'active',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `groups_group_token_unique` (`group_token`),
  KEY `groups_creator_id_foreign` (`creator_id`)
) ENGINE=MyISAM AUTO_INCREMENT=17 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `groups`
--

INSERT INTO `groups` (`id`, `creator_id`, `title`, `description`, `group_token`, `amount_to_join`, `minimum_number_of_people`, `management_fee`, `claims_processing_fee`, `shariah_compliance_review_fee`, `gettakaful_platform_fee`, `total_contributions`, `total_claims_paid`, `pool_balance`, `number_of_active_participants`, `number_of_claims_submitted`, `rules`, `status`, `created_at`, `updated_at`) VALUES
(1, 1, 'Family Health Takaful', 'Mutual health coverage for families in the community.', '2b68e827-4456-4b54-a573-0f410048cd17', 108.00, 8, 12.00, 9.00, 8.00, 5.00, 540.00, 0.00, 540.00, 5, 1, '<p>All members must contribute on time. Claims will be voted on by all members. Majority vote decides approval.</p>', 'active', '2026-03-13 23:02:30', '2026-03-13 23:10:43'),
(2, 1, 'Community Auto Takaful', 'Shared auto insurance for responsible drivers.', 'b28700ae-23d4-47e3-bdbf-b2451cbc04bb', 224.00, 4, 10.00, 9.00, 5.00, 11.00, 896.00, 0.00, 896.00, 4, 1, '<p>All members must contribute on time. Claims will be voted on by all members. Majority vote decides approval.</p>', 'active', '2026-03-13 23:02:30', '2026-03-13 23:10:43'),
(3, 1, 'Student Emergency Fund', 'Emergency financial aid for university students.', '2081a584-f94a-41f2-9f9d-e8fa1e375c8b', 121.00, 3, 6.00, 10.00, 4.00, 7.00, 363.00, 0.00, 363.00, 3, 1, '<p>All members must contribute on time. Claims will be voted on by all members. Majority vote decides approval.</p>', 'pending', '2026-03-13 23:02:30', '2026-03-13 23:26:58'),
(4, 1, 'Small Business Protection', 'Protection fund for small business owners.', '1151276c-001d-484c-a433-30fc0ed4e1c1', 103.00, 8, 5.00, 10.00, 7.00, 11.00, 412.00, 0.00, 412.00, 4, 1, '<p>All members must contribute on time. Claims will be voted on by all members. Majority vote decides approval.</p>', 'active', '2026-03-13 23:02:30', '2026-03-13 23:10:43'),
(5, 1, 'Home Insurance Takaful', 'Home damage and repair mutual coverage.', '8f8f1acb-7eea-478a-8e31-b6bd9e958a1b', 477.00, 9, 12.00, 8.00, 6.00, 9.00, 2385.00, 0.00, 2385.00, 5, 1, '<p>All members must contribute on time. Claims will be voted on by all members. Majority vote decides approval.</p>', 'active', '2026-03-13 23:02:30', '2026-03-13 23:10:43'),
(6, 1, 'Travel Safety Takaful', 'Travel emergency coverage for frequent travelers.', 'bd05b06d-168e-45f4-be8c-bb29dad9569e', 436.00, 4, 8.00, 10.00, 6.00, 12.00, 1744.00, 0.00, 1744.00, 4, 1, '<p>All members must contribute on time. Claims will be voted on by all members. Majority vote decides approval.</p>', 'closed', '2026-03-13 23:02:30', '2026-03-13 23:26:58'),
(7, 1, 'Elderly Care Fund', 'Healthcare support fund for elderly members.', '87b526dc-1ca8-4dde-8e68-e9ccdad03e1d', 143.00, 7, 13.00, 10.00, 2.00, 10.00, 572.00, 0.00, 572.00, 4, 1, '<p>All members must contribute on time. Claims will be voted on by all members. Majority vote decides approval.</p>', 'active', '2026-03-13 23:02:30', '2026-03-13 23:10:43'),
(8, 1, 'Youth Sports Takaful', 'Injury and equipment coverage for youth athletes.', 'f17cca43-6b44-49c6-a223-dfbf12c50895', 379.00, 3, 8.00, 9.00, 4.00, 7.00, 1516.00, 0.00, 1516.00, 4, 1, '<p>All members must contribute on time. Claims will be voted on by all members. Majority vote decides approval.</p>', 'pending', '2026-03-13 23:02:30', '2026-03-13 23:26:58'),
(9, 1, 'Neighborhood Watch Fund', 'Property protection for neighborhood residents.', 'f9d5b8d3-e0d4-4784-958d-3258e9f26bd1', 389.00, 9, 8.00, 6.00, 7.00, 9.00, 1167.00, 0.00, 1167.00, 3, 0, '<p>All members must contribute on time. Claims will be voted on by all members. Majority vote decides approval.</p>', 'active', '2026-03-13 23:02:30', '2026-03-13 23:02:30'),
(10, 1, 'Freelancer Safety Net', 'Income protection for freelance professionals.', 'e84ce2a8-c485-4061-abf1-6e21431cc7f3', 282.00, 7, 14.00, 9.00, 6.00, 5.00, 846.00, 0.00, 846.00, 3, 0, '<p>All members must contribute on time. Claims will be voted on by all members. Majority vote decides approval.</p>', 'inactive', '2026-03-13 23:02:30', '2026-03-13 23:26:58'),
(11, 1, 'Tesla Car Insurance', 'Takaful pool for Tesla vehicle owners providing Shariah-compliant mutual insurance coverage.', 'e32554c7-468d-4085-a970-6ca9d27b64dd', 1000.00, 2, 35.00, 100.00, 70.00, 35.00, 4000.00, 2500.00, 1500.00, 0, 0, '<h3>Membership and Contribution</h3>\n<p>Each participant must contribute 1,000 CAD annually to join the pool.</p>\n<p>The contribution is divided between the Takaful fund (for claims) and operational fees (management, Shariah compliance, etc.).</p>\n<p>Membership is valid for one year from the date of joining and can be renewed by making the next year\'s contribution.</p>\n\n<h3>Claims Process</h3>\n<p>Participants can file claims for covered car accidents, damage, theft, and other insured incidents.</p>\n<p>Claims are reviewed and approved based on the pool\'s guidelines, ensuring the incident is within the policy coverage.</p>\n<p>Claims exceeding the pool balance are deferred to the next year unless the pool reaches a consensus to increase contributions or seek external assistance.</p>\n\n<h3>Surplus Distribution</h3>\n<p>At the end of the year, any surplus remaining in the Takaful fund after covering all claims and expenses is redistributed to participants based on their contributions and claims history.</p>\n<p>Participants who have not filed claims may receive a larger portion of the surplus.</p>\n<p>The redistribution adheres to Shariah guidelines, ensuring fairness and ethical distribution.</p>\n\n<h3>Withdrawal and Early Exit</h3>\n<p>Participants can request to leave the pool at any time, but early exit fees apply (see fee structure below).</p>\n<p>Upon exit, a prorated portion of the contribution is refunded, minus administration and operational fees.</p>\n<p>If the participant has filed claims during the year, refunds may be adjusted accordingly.</p>\n\n<h3>Shariah Compliance</h3>\n<p>All contributions are managed in a Shariah-compliant manner, and any investments made from the pool\'s funds are vetted to ensure compliance.</p>\n<p>A Shariah advisory board oversees the pool\'s operations to ensure all dealings align with Islamic principles.</p>\n\n<h3>Dispute Resolution</h3>\n<p>Any disputes regarding claims or contributions are settled through an internal mediation process.</p>\n<p>If a participant disagrees with the claim decision, they can request a review by the Shariah advisory board.</p>\n\n<h3>Replenishment in Case of Insufficient Funds</h3>\n<p>If the pool runs out of funds before the end of the year, participants may be asked to contribute additional amounts to keep the pool operational.</p>\n<p>This decision is made by a majority vote from the participants or based on the terms outlined at the time of pool creation.</p>', 'active', '2026-03-13 23:46:46', '2026-03-13 23:46:46'),
(12, 1, 'Tesla Car Insurance', 'Takaful pool for Tesla vehicle owners providing Shariah-compliant mutual insurance coverage.', '8cd57f99-9918-4f0d-b240-21e244fd7f47', 1000.00, 2, 35.00, 100.00, 70.00, 35.00, 4000.00, 2500.00, 1500.00, 5, 3, '<h3>Membership and Contribution</h3>\n<p>Each participant must contribute 1,000 CAD annually to join the pool.</p>\n<p>The contribution is divided between the Takaful fund (for claims) and operational fees (management, Shariah compliance, etc.).</p>\n<p>Membership is valid for one year from the date of joining and can be renewed by making the next year\'s contribution.</p>\n\n<h3>Claims Process</h3>\n<p>Participants can file claims for covered car accidents, damage, theft, and other insured incidents.</p>\n<p>Claims are reviewed and approved based on the pool\'s guidelines, ensuring the incident is within the policy coverage.</p>\n<p>Claims exceeding the pool balance are deferred to the next year unless the pool reaches a consensus to increase contributions or seek external assistance.</p>\n\n<h3>Surplus Distribution</h3>\n<p>At the end of the year, any surplus remaining in the Takaful fund after covering all claims and expenses is redistributed to participants based on their contributions and claims history.</p>\n<p>Participants who have not filed claims may receive a larger portion of the surplus.</p>\n<p>The redistribution adheres to Shariah guidelines, ensuring fairness and ethical distribution.</p>\n\n<h3>Withdrawal and Early Exit</h3>\n<p>Participants can request to leave the pool at any time, but early exit fees apply (see fee structure below).</p>\n<p>Upon exit, a prorated portion of the contribution is refunded, minus administration and operational fees.</p>\n<p>If the participant has filed claims during the year, refunds may be adjusted accordingly.</p>\n\n<h3>Shariah Compliance</h3>\n<p>All contributions are managed in a Shariah-compliant manner, and any investments made from the pool\'s funds are vetted to ensure compliance.</p>\n<p>A Shariah advisory board oversees the pool\'s operations to ensure all dealings align with Islamic principles.</p>\n\n<h3>Dispute Resolution</h3>\n<p>Any disputes regarding claims or contributions are settled through an internal mediation process.</p>\n<p>If a participant disagrees with the claim decision, they can request a review by the Shariah advisory board.</p>\n\n<h3>Replenishment in Case of Insufficient Funds</h3>\n<p>If the pool runs out of funds before the end of the year, participants may be asked to contribute additional amounts to keep the pool operational.</p>\n<p>This decision is made by a majority vote from the participants or based on the terms outlined at the time of pool creation.</p>', 'active', '2026-03-13 23:47:28', '2026-03-14 00:57:36'),
(13, 3, 'Vancouver Renters Protection', 'A community Takaful group.', '39c774e0-6250-4662-b8dd-6605b5c5ed50', 250.00, 5, 30.00, 17.00, 10.00, 6.00, 500.00, 0.00, 500.00, 2, 0, '<p>Standard Takaful rules apply.</p>', 'active', '2026-03-14 00:13:24', '2026-03-14 00:13:24'),
(14, 4, 'Calgary Drivers Takaful', 'A community Takaful group.', '74e30959-285f-4e6f-93c7-379e79632848', 400.00, 3, 23.00, 14.00, 7.00, 15.00, 800.00, 0.00, 800.00, 2, 0, '<p>Standard Takaful rules apply.</p>', 'active', '2026-03-14 00:13:24', '2026-03-14 00:13:24'),
(15, 5, 'Montreal Health Pool', 'A community Takaful group.', '25fdd5a8-b8c0-41b8-86d6-2c2ee69d44e2', 300.00, 4, 20.00, 6.00, 7.00, 5.00, 600.00, 0.00, 600.00, 2, 0, '<p>Standard Takaful rules apply.</p>', 'pending', '2026-03-14 00:13:24', '2026-03-14 00:13:24'),
(16, 3, 'Family Insurance', 'A comprehensive family insurance Takaful pool providing coverage for health, home, and vehicle incidents for families in the community.', '6477f259-5405-413e-a9f8-4685af33d75c', 500.00, 5, 25.00, 15.00, 10.00, 20.00, 2000.00, 500.00, 1500.00, 3, 1, '<h3>Family Insurance Rules</h3><p>All family members are covered under this pool. Each family must contribute 500 CAD annually.</p><h3>Claims</h3><p>Claims must be filed within 30 days of the incident. All claims require supporting documentation.</p><h3>Voting</h3><p>Claims are approved by majority vote of pool members within 7 days.</p>', 'active', '2026-03-14 01:27:27', '2026-03-14 01:27:27');

-- --------------------------------------------------------

--
-- Table structure for table `group_members`
--

DROP TABLE IF EXISTS `group_members`;
CREATE TABLE IF NOT EXISTS `group_members` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `group_id` bigint UNSIGNED NOT NULL,
  `user_id` bigint UNSIGNED NOT NULL,
  `role` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'member',
  `status` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'active',
  `vehicle_make` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `vehicle_model` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `identification_number` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `registration_number` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `engine_size_capacity` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `group_members_group_id_user_id_unique` (`group_id`,`user_id`),
  KEY `group_members_user_id_foreign` (`user_id`)
) ENGINE=MyISAM AUTO_INCREMENT=62 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `group_members`
--

INSERT INTO `group_members` (`id`, `group_id`, `user_id`, `role`, `status`, `vehicle_make`, `vehicle_model`, `identification_number`, `registration_number`, `engine_size_capacity`, `created_at`, `updated_at`) VALUES
(1, 1, 1, 'admin', 'active', NULL, NULL, NULL, NULL, NULL, '2026-03-13 23:02:30', '2026-03-13 23:02:30'),
(2, 1, 6, 'member', 'active', NULL, NULL, NULL, NULL, NULL, '2026-03-13 23:02:30', '2026-03-13 23:02:30'),
(3, 1, 5, 'member', 'active', NULL, NULL, NULL, NULL, NULL, '2026-03-13 23:02:30', '2026-03-13 23:02:30'),
(4, 1, 7, 'member', 'active', NULL, NULL, NULL, NULL, NULL, '2026-03-13 23:02:30', '2026-03-13 23:02:30'),
(5, 2, 1, 'admin', 'active', NULL, NULL, NULL, NULL, NULL, '2026-03-13 23:02:30', '2026-03-13 23:02:30'),
(6, 2, 7, 'member', 'active', NULL, NULL, NULL, NULL, NULL, '2026-03-13 23:02:30', '2026-03-13 23:02:30'),
(7, 2, 3, 'member', 'active', NULL, NULL, NULL, NULL, NULL, '2026-03-13 23:02:30', '2026-03-13 23:02:30'),
(8, 3, 1, 'admin', 'active', NULL, NULL, NULL, NULL, NULL, '2026-03-13 23:02:30', '2026-03-13 23:02:30'),
(9, 3, 5, 'member', 'active', NULL, NULL, NULL, NULL, NULL, '2026-03-13 23:02:30', '2026-03-13 23:02:30'),
(10, 3, 6, 'member', 'active', NULL, NULL, NULL, NULL, NULL, '2026-03-13 23:02:30', '2026-03-13 23:02:30'),
(11, 4, 1, 'admin', 'active', NULL, NULL, NULL, NULL, NULL, '2026-03-13 23:02:30', '2026-03-13 23:02:30'),
(12, 4, 3, 'member', 'active', NULL, NULL, NULL, NULL, NULL, '2026-03-13 23:02:30', '2026-03-13 23:02:30'),
(13, 4, 4, 'member', 'active', NULL, NULL, NULL, NULL, NULL, '2026-03-13 23:02:30', '2026-03-13 23:02:30'),
(14, 5, 1, 'admin', 'active', NULL, NULL, NULL, NULL, NULL, '2026-03-13 23:02:30', '2026-03-13 23:02:30'),
(15, 5, 5, 'member', 'active', NULL, NULL, NULL, NULL, NULL, '2026-03-13 23:02:30', '2026-03-13 23:02:30'),
(16, 5, 6, 'member', 'active', NULL, NULL, NULL, NULL, NULL, '2026-03-13 23:02:30', '2026-03-13 23:02:30'),
(17, 5, 3, 'member', 'active', NULL, NULL, NULL, NULL, NULL, '2026-03-13 23:02:30', '2026-03-13 23:02:30'),
(18, 6, 1, 'admin', 'active', NULL, NULL, NULL, NULL, NULL, '2026-03-13 23:02:30', '2026-03-13 23:02:30'),
(19, 6, 7, 'member', 'active', NULL, NULL, NULL, NULL, NULL, '2026-03-13 23:02:30', '2026-03-13 23:02:30'),
(20, 6, 5, 'member', 'active', NULL, NULL, NULL, NULL, NULL, '2026-03-13 23:02:30', '2026-03-13 23:02:30'),
(21, 6, 6, 'member', 'active', NULL, NULL, NULL, NULL, NULL, '2026-03-13 23:02:30', '2026-03-13 23:02:30'),
(22, 7, 1, 'admin', 'active', NULL, NULL, NULL, NULL, NULL, '2026-03-13 23:02:30', '2026-03-13 23:02:30'),
(23, 7, 7, 'member', 'active', NULL, NULL, NULL, NULL, NULL, '2026-03-13 23:02:30', '2026-03-13 23:02:30'),
(24, 7, 6, 'member', 'active', NULL, NULL, NULL, NULL, NULL, '2026-03-13 23:02:30', '2026-03-13 23:02:30'),
(25, 7, 5, 'member', 'active', NULL, NULL, NULL, NULL, NULL, '2026-03-13 23:02:30', '2026-03-13 23:02:30'),
(26, 8, 1, 'admin', 'active', NULL, NULL, NULL, NULL, NULL, '2026-03-13 23:02:30', '2026-03-13 23:02:30'),
(27, 8, 3, 'member', 'active', NULL, NULL, NULL, NULL, NULL, '2026-03-13 23:02:30', '2026-03-13 23:02:30'),
(28, 8, 6, 'member', 'active', NULL, NULL, NULL, NULL, NULL, '2026-03-13 23:02:30', '2026-03-13 23:02:30'),
(29, 8, 4, 'member', 'active', NULL, NULL, NULL, NULL, NULL, '2026-03-13 23:02:30', '2026-03-13 23:02:30'),
(30, 9, 1, 'admin', 'active', NULL, NULL, NULL, NULL, NULL, '2026-03-13 23:02:30', '2026-03-13 23:02:30'),
(31, 9, 5, 'member', 'active', NULL, NULL, NULL, NULL, NULL, '2026-03-13 23:02:30', '2026-03-13 23:02:30'),
(32, 9, 4, 'member', 'active', NULL, NULL, NULL, NULL, NULL, '2026-03-13 23:02:30', '2026-03-13 23:02:30'),
(33, 10, 1, 'admin', 'active', NULL, NULL, NULL, NULL, NULL, '2026-03-13 23:02:30', '2026-03-13 23:02:30'),
(34, 10, 3, 'member', 'active', NULL, NULL, NULL, NULL, NULL, '2026-03-13 23:02:30', '2026-03-13 23:02:30'),
(35, 10, 6, 'member', 'active', NULL, NULL, NULL, NULL, NULL, '2026-03-13 23:02:30', '2026-03-13 23:02:30'),
(36, 1, 3, 'member', 'active', NULL, NULL, NULL, NULL, NULL, '2026-03-13 23:10:43', '2026-03-13 23:10:43'),
(37, 2, 4, 'member', 'active', NULL, NULL, NULL, NULL, NULL, '2026-03-13 23:10:43', '2026-03-13 23:10:43'),
(38, 4, 6, 'member', 'active', NULL, NULL, NULL, NULL, NULL, '2026-03-13 23:10:43', '2026-03-13 23:10:43'),
(39, 5, 7, 'member', 'active', NULL, NULL, NULL, NULL, NULL, '2026-03-13 23:10:43', '2026-03-13 23:10:43'),
(40, 11, 1, 'admin', 'active', NULL, NULL, NULL, NULL, NULL, '2026-03-13 23:46:46', '2026-03-13 23:46:46'),
(41, 11, 3, 'member', 'active', NULL, NULL, NULL, NULL, NULL, '2026-03-13 23:46:46', '2026-03-13 23:46:46'),
(42, 11, 4, 'member', 'active', NULL, NULL, NULL, NULL, NULL, '2026-03-13 23:46:46', '2026-03-13 23:46:46'),
(43, 11, 5, 'member', 'active', NULL, NULL, NULL, NULL, NULL, '2026-03-13 23:46:46', '2026-03-13 23:46:46'),
(55, 12, 9, 'member', 'active', '2012', 'WSD234', '1234', '5678', '3400', '2026-03-14 00:57:36', '2026-03-14 00:57:36'),
(54, 12, 8, 'admin', 'active', 'Tesla', 'M3', '223949595999', 'MF5TR4', '3.5L', '2026-03-14 00:57:36', '2026-03-14 00:57:36'),
(48, 13, 3, 'admin', 'active', NULL, NULL, NULL, NULL, NULL, '2026-03-14 00:13:24', '2026-03-14 00:13:24'),
(49, 13, 1, 'member', 'active', NULL, NULL, NULL, NULL, NULL, '2026-03-14 00:13:24', '2026-03-14 00:13:24'),
(50, 14, 4, 'admin', 'active', NULL, NULL, NULL, NULL, NULL, '2026-03-14 00:13:24', '2026-03-14 00:13:24'),
(51, 14, 1, 'member', 'active', NULL, NULL, NULL, NULL, NULL, '2026-03-14 00:13:24', '2026-03-14 00:13:24'),
(52, 15, 5, 'admin', 'active', NULL, NULL, NULL, NULL, NULL, '2026-03-14 00:13:24', '2026-03-14 00:13:24'),
(53, 15, 1, 'member', 'active', NULL, NULL, NULL, NULL, NULL, '2026-03-14 00:13:24', '2026-03-14 00:13:24'),
(56, 12, 10, 'member', 'active', 'Tesla', 'Model Y', '1112233434345', 'GTCD454', '2000', '2026-03-14 00:57:36', '2026-03-14 00:57:36'),
(57, 12, 1, 'member', 'active', 'Tesla', 'Model X', '5YJXCBE24KF152671', 'BXFB185', 'Dual Motor - Standard', '2026-03-14 00:57:36', '2026-03-14 00:57:36'),
(58, 12, 11, 'member', 'active', 'Tesla', 'Model 3', '123455544', 'SFTV343', '2000', '2026-03-14 00:57:36', '2026-03-14 00:57:36'),
(59, 16, 3, 'admin', 'active', NULL, NULL, NULL, NULL, NULL, '2026-03-14 01:27:27', '2026-03-14 01:27:27'),
(60, 16, 4, 'member', 'active', NULL, NULL, NULL, NULL, NULL, '2026-03-14 01:27:27', '2026-03-14 01:27:27'),
(61, 16, 5, 'member', 'active', NULL, NULL, NULL, NULL, NULL, '2026-03-14 01:27:27', '2026-03-14 01:27:27');

-- --------------------------------------------------------

--
-- Table structure for table `invitations`
--

DROP TABLE IF EXISTS `invitations`;
CREATE TABLE IF NOT EXISTS `invitations` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `group_id` bigint UNSIGNED NOT NULL,
  `invited_by` bigint UNSIGNED NOT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'pending',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `invitations_group_id_foreign` (`group_id`),
  KEY `invitations_invited_by_foreign` (`invited_by`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `jobs`
--

DROP TABLE IF EXISTS `jobs`;
CREATE TABLE IF NOT EXISTS `jobs` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `queue` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `attempts` tinyint UNSIGNED NOT NULL,
  `reserved_at` int UNSIGNED DEFAULT NULL,
  `available_at` int UNSIGNED NOT NULL,
  `created_at` int UNSIGNED NOT NULL,
  PRIMARY KEY (`id`),
  KEY `jobs_queue_reserved_at_available_at_index` (`queue`,`reserved_at`,`available_at`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `job_batches`
--

DROP TABLE IF EXISTS `job_batches`;
CREATE TABLE IF NOT EXISTS `job_batches` (
  `id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `total_jobs` int NOT NULL,
  `pending_jobs` int NOT NULL,
  `failed_jobs` int NOT NULL,
  `failed_job_ids` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `options` mediumtext COLLATE utf8mb4_unicode_ci,
  `cancelled_at` int DEFAULT NULL,
  `created_at` int NOT NULL,
  `finished_at` int DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

DROP TABLE IF EXISTS `migrations`;
CREATE TABLE IF NOT EXISTS `migrations` (
  `id` int UNSIGNED NOT NULL AUTO_INCREMENT,
  `migration` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '0001_01_01_000000_create_users_table', 1),
(2, '0001_01_01_000001_create_cache_table', 1),
(3, '0001_01_01_000002_create_jobs_table', 1),
(4, '2026_03_12_000001_create_groups_table', 1),
(5, '2026_03_12_000002_create_claims_table', 1),
(6, '2026_03_12_000003_create_invitations_table', 1),
(7, '2026_03_12_095245_create_personal_access_tokens_table', 1),
(8, '2026_03_14_065518_add_vehicle_fields_to_group_members_table', 2),
(9, '2026_03_14_100000_add_address_fields_to_users_table', 3);

-- --------------------------------------------------------

--
-- Table structure for table `password_reset_tokens`
--

DROP TABLE IF EXISTS `password_reset_tokens`;
CREATE TABLE IF NOT EXISTS `password_reset_tokens` (
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`email`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `personal_access_tokens`
--

DROP TABLE IF EXISTS `personal_access_tokens`;
CREATE TABLE IF NOT EXISTS `personal_access_tokens` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `tokenable_type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tokenable_id` bigint UNSIGNED NOT NULL,
  `name` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `abilities` text COLLATE utf8mb4_unicode_ci,
  `last_used_at` timestamp NULL DEFAULT NULL,
  `expires_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `personal_access_tokens_token_unique` (`token`),
  KEY `personal_access_tokens_tokenable_type_tokenable_id_index` (`tokenable_type`,`tokenable_id`),
  KEY `personal_access_tokens_expires_at_index` (`expires_at`)
) ENGINE=MyISAM AUTO_INCREMENT=17 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `personal_access_tokens`
--

INSERT INTO `personal_access_tokens` (`id`, `tokenable_type`, `tokenable_id`, `name`, `token`, `abilities`, `last_used_at`, `expires_at`, `created_at`, `updated_at`) VALUES
(1, 'App\\Models\\User', 1, 'auth-token', '2d4846ad953af7dbea9951417689cbee68e117493f9051b244e0268ef2362a04', '[\"*\"]', '2026-03-12 04:48:47', NULL, '2026-03-12 04:28:52', '2026-03-12 04:48:47'),
(2, 'App\\Models\\User', 1, 'auth-token', '6c12b34050989630cf05ce5a47f15ad6a848942661199ef8e61d12a9623ad16c', '[\"*\"]', '2026-03-12 05:28:27', NULL, '2026-03-12 04:51:20', '2026-03-12 05:28:27'),
(6, 'App\\Models\\User', 2, 'auth-token', '548f3fff1a33a7a794966534a02dd3df5433efd2abc5db565715f1d14c4d6af2', '[\"*\"]', NULL, NULL, '2026-03-13 22:36:09', '2026-03-13 22:36:09'),
(4, 'App\\Models\\User', 1, 'auth-token', 'c26f15618e81de0259989b3d0b6da07ac1940cfa6a94b1d19d46886e4f89be21', '[\"*\"]', '2026-03-13 21:33:47', NULL, '2026-03-13 21:32:13', '2026-03-13 21:33:47'),
(10, 'App\\Models\\User', 1, 'auth-token', '5cc9c776420bd5fe0362108daa56149e4b4b0ada0597fb28ccabbb2a39e483ba', '[\"*\"]', '2026-03-14 00:43:05', NULL, '2026-03-13 23:00:55', '2026-03-14 00:43:05'),
(11, 'App\\Models\\User', 1, 'auth-token', '6e8e9d0d9628f3b169b501cc18b4a842874372db4e9d12e436c06dbb1deac4e6', '[\"*\"]', '2026-03-14 00:42:37', NULL, '2026-03-13 23:03:46', '2026-03-14 00:42:37'),
(12, 'App\\Models\\User', 1, 'test', 'afa2539f0d05ed66da31398df70ab7ff522c99d722ec8ad5ac17e7b40c009401', '[\"*\"]', '2026-03-14 00:14:40', NULL, '2026-03-13 23:05:06', '2026-03-14 00:14:40'),
(14, 'App\\Models\\User', 1, 'auth-token', 'a6328df23bfa77c5707dcf46c9ad96e1e417d2fecf68a2792cf55785922715a1', '[\"*\"]', '2026-03-14 02:16:33', NULL, '2026-03-14 00:43:49', '2026-03-14 02:16:33'),
(15, 'App\\Models\\User', 1, 'auth-token', 'f80cd43ec3a8aee25621e87d4e4cd74fd25fdbb40f44e902e32b23949e6582cc', '[\"*\"]', '2026-03-14 01:24:22', NULL, '2026-03-14 00:48:42', '2026-03-14 01:24:22'),
(16, 'App\\Models\\User', 12, 'auth-token', '0ee5630adefe840a95562de712dff1288184cb2e72df17871405b1106fff29d6', '[\"*\"]', '2026-03-14 01:41:21', NULL, '2026-03-14 01:29:01', '2026-03-14 01:41:21');

-- --------------------------------------------------------

--
-- Table structure for table `sessions`
--

DROP TABLE IF EXISTS `sessions`;
CREATE TABLE IF NOT EXISTS `sessions` (
  `id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` bigint UNSIGNED DEFAULT NULL,
  `ip_address` varchar(45) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_agent` text COLLATE utf8mb4_unicode_ci,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `last_activity` int NOT NULL,
  PRIMARY KEY (`id`),
  KEY `sessions_user_id_index` (`user_id`),
  KEY `sessions_last_activity_index` (`last_activity`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `sessions`
--

INSERT INTO `sessions` (`id`, `user_id`, `ip_address`, `user_agent`, `payload`, `last_activity`) VALUES
('UhGwOk3KIuP1HERcFCRnxbhq4tzV0qq7hQnbuidk', NULL, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', 'YToyOntzOjY6Il90b2tlbiI7czo0MDoiRlVFRmRIQTRMVHR3U1RZNzFnMldValVUQ0dHUUZrT3NOUlNxTHJpbyI7czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==', 1773311120),
('su8hjwTx3pO7F4RWWvsxKsGNzkJUdPqGSRyBtWHM', NULL, '127.0.0.1', 'curl/8.18.0', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiSjh6UkUxUFRST2ZFbEx6aFo2eGEwUW0xd093TXdTUXYyQzdpS2lLbiI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjE6Imh0dHA6Ly9sb2NhbGhvc3Q6ODAwMCI7czo1OiJyb3V0ZSI7Tjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==', 1773460152);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE IF NOT EXISTS `users` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `first_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `last_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `street_address` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `address_line_2` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `city` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `province` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `knows_shariah_insurance` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `insurance_experience` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `expectation` text COLLATE utf8mb4_unicode_ci,
  `password` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `profile_picture` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `otp_code` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `otp_expires_at` timestamp NULL DEFAULT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`)
) ENGINE=MyISAM AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `first_name`, `last_name`, `email`, `phone`, `street_address`, `address_line_2`, `city`, `province`, `knows_shariah_insurance`, `insurance_experience`, `expectation`, `password`, `profile_picture`, `email_verified_at`, `otp_code`, `otp_expires_at`, `remember_token`, `created_at`, `updated_at`) VALUES
(1, 'Biplab', 'Paul', 'biplab.cse.85@gmail.com', NULL, '1127 17 Ave SW #200', NULL, 'Calgary', 'Alberta', 'Yes', 'No Experience', '<p></p>', '$2y$12$NWzP4jQ9jqGHW093VNnrg.VkppReVzcGgw.VNmfRarlqq2ne8pnGW', 'profiles/SeNSWSCNI22AZss6FrKJBaeLPoOkrZlFlET58UaH.webp', NULL, '$2y$12$hkgcxMtfEgUIP5gCtyGK2uJ1NnMij97mrcvcjyGYh9qwX0/sJ4pGm', '2026-03-13 22:15:14', NULL, '2026-03-12 04:24:08', '2026-03-14 01:59:01'),
(2, 'Biplab', 'Paul', 'biplab.cse.85+1@gmail.com', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '$2y$12$NWzP4jQ9jqGHW093VNnrg.VkppReVzcGgw.VNmfRarlqq2ne8pnGW', NULL, NULL, NULL, NULL, NULL, '2026-03-13 22:36:09', '2026-03-14 01:59:01'),
(3, 'User', 'Test1', 'testuser1@gettakaful.com', '1234567891', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '$2y$12$NWzP4jQ9jqGHW093VNnrg.VkppReVzcGgw.VNmfRarlqq2ne8pnGW', NULL, NULL, NULL, NULL, NULL, '2026-03-13 23:02:09', '2026-03-14 01:59:01'),
(4, 'User', 'Test2', 'testuser2@gettakaful.com', '1234567892', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '$2y$12$NWzP4jQ9jqGHW093VNnrg.VkppReVzcGgw.VNmfRarlqq2ne8pnGW', NULL, NULL, NULL, NULL, NULL, '2026-03-13 23:02:09', '2026-03-14 01:59:01'),
(5, 'User', 'Test3', 'testuser3@gettakaful.com', '1234567893', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '$2y$12$NWzP4jQ9jqGHW093VNnrg.VkppReVzcGgw.VNmfRarlqq2ne8pnGW', NULL, NULL, NULL, NULL, NULL, '2026-03-13 23:02:09', '2026-03-14 01:59:01'),
(6, 'User', 'Test4', 'testuser4@gettakaful.com', '1234567894', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '$2y$12$NWzP4jQ9jqGHW093VNnrg.VkppReVzcGgw.VNmfRarlqq2ne8pnGW', NULL, NULL, NULL, NULL, NULL, '2026-03-13 23:02:10', '2026-03-14 01:59:01'),
(7, 'User', 'Test5', 'testuser5@gettakaful.com', '1234567895', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '$2y$12$NWzP4jQ9jqGHW093VNnrg.VkppReVzcGgw.VNmfRarlqq2ne8pnGW', NULL, NULL, NULL, NULL, NULL, '2026-03-13 23:02:10', '2026-03-14 01:59:01'),
(8, 'Test', 'Takaful', 'yixera4386@aiwanlab.com', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '$2y$12$NWzP4jQ9jqGHW093VNnrg.VkppReVzcGgw.VNmfRarlqq2ne8pnGW', NULL, NULL, NULL, NULL, NULL, '2026-03-14 00:57:35', '2026-03-14 01:59:01'),
(9, 'Rafiatun', 'Zannat', 'mroni78@gmail.com', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '$2y$12$NWzP4jQ9jqGHW093VNnrg.VkppReVzcGgw.VNmfRarlqq2ne8pnGW', NULL, NULL, NULL, NULL, NULL, '2026-03-14 00:57:35', '2026-03-14 01:59:01'),
(10, 'Rishad', 'Bin Wahid', 'info@sklentr.com', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '$2y$12$NWzP4jQ9jqGHW093VNnrg.VkppReVzcGgw.VNmfRarlqq2ne8pnGW', NULL, NULL, NULL, NULL, NULL, '2026-03-14 00:57:35', '2026-03-14 01:59:01'),
(11, 'GetTakaful', 'Inc.', 'tanzilur@sklentr.com', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '$2y$12$NWzP4jQ9jqGHW093VNnrg.VkppReVzcGgw.VNmfRarlqq2ne8pnGW', NULL, NULL, NULL, NULL, NULL, '2026-03-14 00:57:36', '2026-03-14 01:59:01'),
(12, 'Sarah', 'Ahmed', 'sarah.ahmed@gettakaful.com', '4165551234', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '$2y$12$NWzP4jQ9jqGHW093VNnrg.VkppReVzcGgw.VNmfRarlqq2ne8pnGW', 'profiles/GlODKluflcJqHZPAeU0kLs9fxqRUrD1Dpny3qU8h.jpg', NULL, NULL, NULL, NULL, '2026-03-14 01:27:27', '2026-03-14 01:59:01');

-- --------------------------------------------------------

--
-- Table structure for table `votes`
--

DROP TABLE IF EXISTS `votes`;
CREATE TABLE IF NOT EXISTS `votes` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `claim_id` bigint UNSIGNED NOT NULL,
  `user_id` bigint UNSIGNED NOT NULL,
  `decision` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `comment` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `votes_claim_id_user_id_unique` (`claim_id`,`user_id`),
  KEY `votes_user_id_foreign` (`user_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
